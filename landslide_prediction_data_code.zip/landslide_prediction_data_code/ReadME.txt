cnn_lstm_best_model_paper.pth is the weight of model from "AI-powered landslide susceptibility assessment in Hong Kong"
lai_geoenv_test_all_model_all.pth is the weight of model from "A novel vegetation-aware deep learning model for predicting landslides including the effect of antecedent rainfall"

run_eval.py is the code for evaluating the result of model from "A novel vegetation-aware deep learning model for predicting landslides including the effect of antecedent rainfall"

To get the metrics

python run_eval.py 

run_eval_other_sota.py is the code for evaluating the result of model from "AI-powered landslide susceptibility assessment in Hong Kong"

python run_eval_other_sota.py